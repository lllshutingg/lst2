// Supabase 项目配置（publishable key 可公开，安全性由数据库的行级安全保证）
window.SUPABASE_CONFIG = {
  url: "https://wrqtkufyysifcdsdhtql.supabase.co",
  anonKey: "sb_publishable_AVv655n47LWpGGGeEEzR2g_B2OhSGWc"
};
