/* Supabase 同步层：用 Supabase 实现页面原本使用的 window.claude.use('db') / ('user') 接口 */
(function () {
  var cfg = window.SUPABASE_CONFIG || {};
  if (!cfg.url || !cfg.anonKey || !window.supabase) return; // 未配置 → 保持本地模式
  var sb = window.supabase.createClient(cfg.url, cfg.anonKey);
  var TABLE = 'app_docs';
  var session = null, uid = null;

  var ready = sb.auth.getSession().then(function (r) {
    session = r.data && r.data.session; uid = session ? session.user.id : null;
  });

  /* ---------- 实时变更总线 ---------- */
  var listeners = [], channel = null, timer = null;
  function ensureChannel() {
    if (channel || !uid) return;
    channel = sb.channel('app_docs_' + uid + '_' + Math.random().toString(36).slice(2, 6))
      .on('postgres_changes', { event: '*', schema: 'public', table: TABLE, filter: 'user_id=eq.' + uid }, function () {
        clearTimeout(timer);
        timer = setTimeout(function () { listeners.slice().forEach(function (fn) { fn(); }); }, 250);
      }).subscribe();
  }
  function listen(fetchAndEmit) {
    listeners.push(fetchAndEmit); ensureChannel(); fetchAndEmit();
    return function () { listeners = listeners.filter(function (f) { return f !== fetchAndEmit; }); };
  }

  /* ---------- Firestore 风格的最小实现 ---------- */
  function docSnap(row) {
    return { exists: !!row, data: function () { return row ? row.data : undefined; }, metadata: { hasPendingWrites: false } };
  }
  function docRef(id) {
    return {
      get: async function () {
        var r = await sb.from(TABLE).select('data').eq('doc_id', id).maybeSingle();
        if (r.error) throw r.error; return docSnap(r.data);
      },
      set: async function (obj) {
        var r = await sb.from(TABLE).upsert({ user_id: uid, doc_id: id, data: obj, updated_at: new Date().toISOString() }, { onConflict: 'user_id,doc_id' });
        if (r.error) throw r.error;
      },
      delete: async function () {
        var r = await sb.from(TABLE).delete().eq('doc_id', id);
        if (r.error) throw r.error;
      },
      onSnapshot: function (ok, fail) {
        return listen(function () {
          sb.from(TABLE).select('data').eq('doc_id', id).maybeSingle().then(function (r) {
            if (r.error) { fail && fail(r.error); return; } ok(docSnap(r.data));
          });
        });
      }
    };
  }
  function query(field, val) {
    return {
      onSnapshot: function (ok, fail) {
        return listen(function () {
          sb.from(TABLE).select('doc_id,data').eq('data->>' + field, val).then(function (r) {
            if (r.error) { fail && fail(r.error); return; }
            ok({ docs: r.data.map(function (row) { return { data: function () { return row.data; } }; }) });
          });
        });
      }
    };
  }
  var db = {
    collection: function () {
      return { doc: docRef, where: function (f, op, v) { return query(f, v); } };
    }
  };
  var user = { id: async function () { await ready; return uid; } };

  window.claude = { use: async function (name) {
    await ready;
    if (name === 'db') return db;
    if (name === 'user') return user;
    return null;
  } };

  /* ---------- 登录弹窗（点击右上角同步状态） ---------- */
  function css() {
    var s = document.createElement('style');
    s.textContent = '#sbm{position:fixed;inset:0;background:rgba(74,59,71,.45);display:flex;align-items:center;justify-content:center;z-index:9999;padding:16px}' +
      '#sbm .box{background:#fff;border-radius:24px;padding:22px;max-width:340px;width:100%;box-shadow:0 12px 40px rgba(0,0,0,.2);font-size:14px}' +
      '#sbm h3{font-size:22px;margin:0 0 6px}#sbm p{color:var(--muted);margin:0 0 12px;font-size:12px}' +
      '#sbm input{width:100%;padding:10px 12px;border:2px solid var(--line);border-radius:14px;margin-bottom:8px;font:inherit}' +
      '#sbm button{padding:9px 14px;border-radius:99px;border:2px solid var(--line);background:#fff;margin-right:6px}' +
      '#sbm button.pri{background:var(--pink);color:#fff;border-color:var(--pink)}#sbm .err{color:#e0566f;min-height:18px;margin:4px 0}';
    document.head.appendChild(s);
  }
  function open() {
    var m = document.createElement('div'); m.id = 'sbm';
    function close() { m.remove(); }
    m.addEventListener('click', function (e) { if (e.target === m) close(); });
    if (uid) {
      m.innerHTML = '<div class="box"><h3>☁ 账号同步</h3><p>已登录：' + (session.user.email || '') + '</p><div class="err"></div><button class="pri" id="sbx">退出登录</button><button id="sbc">关闭</button></div>';
      document.body.appendChild(m);
      m.querySelector('#sbc').onclick = close;
      m.querySelector('#sbx').onclick = async function () { await sb.auth.signOut(); location.reload(); };
      return;
    }
    m.innerHTML = '<div class="box"><h3>☁ 登录以跨设备同步</h3><p>首次使用请点“注册”。密码至少 6 位。</p>' +
      '<input id="sbe" type="email" placeholder="邮箱" autocomplete="email"><input id="sbp" type="password" placeholder="密码" autocomplete="current-password">' +
      '<div class="err"></div><button class="pri" id="sbl">登录</button><button id="sbr">注册</button><button id="sbc">取消</button></div>';
    document.body.appendChild(m);
    var err = m.querySelector('.err');
    function creds() { return { email: m.querySelector('#sbe').value.trim(), password: m.querySelector('#sbp').value }; }
    m.querySelector('#sbc').onclick = close;
    m.querySelector('#sbl').onclick = async function () {
      var r = await sb.auth.signInWithPassword(creds());
      if (r.error) err.textContent = r.error.message; else location.reload();
    };
    m.querySelector('#sbr').onclick = async function () {
      var r = await sb.auth.signUp(creds());
      if (r.error) err.textContent = r.error.message;
      else if (r.data.session) location.reload();
      else err.textContent = '注册成功，请到邮箱点击确认链接后再登录。';
    };
  }
  css();
  document.addEventListener('click', function (e) {
    var t = e.target.closest && e.target.closest('#sync');
    if (t) open();
  });
  document.addEventListener('DOMContentLoaded', function () {
    var el = document.getElementById('sync'); if (el) { el.style.cursor = 'pointer'; el.title = '点击登录 / 管理同步'; }
  });
})();
