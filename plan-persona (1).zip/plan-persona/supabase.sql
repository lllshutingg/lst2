-- 在 Supabase 控制台 → SQL Editor 里整段运行
create table if not exists public.app_docs (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  doc_id     text not null,
  data       jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, doc_id)
);

alter table public.app_docs enable row level security;

create policy "own rows select" on public.app_docs for select using (auth.uid() = user_id);
create policy "own rows insert" on public.app_docs for insert with check (auth.uid() = user_id);
create policy "own rows update" on public.app_docs for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own rows delete" on public.app_docs for delete using (auth.uid() = user_id);

-- 开启实时同步（其他设备的改动会自动推送过来）
alter publication supabase_realtime add table public.app_docs;
